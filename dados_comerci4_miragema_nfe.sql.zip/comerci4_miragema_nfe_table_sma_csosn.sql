
--
-- Extraindo dados da tabela `sma_csosn`
--

INSERT INTO `sma_csosn` (`id`, `descricao`) VALUES
(101, '101 - Tributada pelo Simples Nacional com permissão de crédito'),
(102, '102 - Tributada pelo Simples Nacional sem permissão de crédito.'),
(103, '103 - Isenção do ICMS no Simples Nacional para faixa de receita bruta.'),
(201, '201 - Tributada pelo Simples Nacional com permissão de crédito e com cobrança do ICMS por substituição tributária.'),
(202, '202 - Tributada pelo Simples Nacional sem permissão de crédito e com cobrança do ICMS por substituição tributária. '),
(203, '203 - Isenção do ICMS no Simples Nacional para faixa de receita bruta e com cobrança do ICMS por substituição tributária.'),
(300, '300 - Imune.'),
(400, '400 - Não tributada pelo Simples Nacional.'),
(500, '500 - ICMS cobrado anteriormente por substituição tributária (substituído) ou por antecipação.'),
(900, '900 - Outros.');
