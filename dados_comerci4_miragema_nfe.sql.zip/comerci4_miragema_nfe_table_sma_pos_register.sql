
--
-- Extraindo dados da tabela `sma_pos_register`
--

INSERT INTO `sma_pos_register` (`id`, `date`, `user_id`, `cash_in_hand`, `status`, `total_cash`, `total_cheques`, `total_cc_slips`, `total_cash_submitted`, `total_cheques_submitted`, `total_cc_slips_submitted`, `note`, `closed_at`, `transfer_opened_bills`, `closed_by`) VALUES
(1, '2016-05-17 16:12:07', 1, '10.0000', 'close', '43.9000', 0, 0, '43.9000', 0, 0, '', '2016-05-19 01:50:47', NULL, 1),
(2, '2016-05-20 14:08:54', 1, '10.0000', 'close', '43.9000', 0, 1, '43.9000', 0, 1, '', '2019-02-01 16:35:33', '0', 4),
(3, '2016-07-28 15:13:58', 2, '20.0000', 'close', '206.4500', 0, 0, '206.4500', 0, 0, '', '2017-06-06 18:05:43', NULL, 2),
(4, '2017-06-06 18:10:01', 2, '0.0000', 'close', '40.7300', 0, 0, '40.7300', 0, 0, '', '2019-02-01 16:35:43', NULL, 4),
(5, '2017-06-09 22:57:31', 3, '10.0000', 'close', '43.9000', 0, 0, '43.9000', 0, 0, '', '2019-02-01 16:35:55', NULL, 4),
(6, '2019-02-01 12:03:56', 4, '20.0000', 'close', '20.0000', 0, 0, '20.0000', 0, 0, '', '2019-02-01 16:35:49', NULL, 4),
(7, '2019-02-01 16:36:01', 4, '10.0000', 'open', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
