
--
-- Extraindo dados da tabela `sma_business_type`
--

INSERT INTO `sma_business_type` (`id`, `descricao`) VALUES
(1, 'Simples Nacional'),
(2, 'Lucro Real'),
(3, 'Lucro Presumido');
