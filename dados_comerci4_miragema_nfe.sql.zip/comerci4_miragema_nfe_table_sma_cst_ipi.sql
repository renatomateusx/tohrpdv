
--
-- Extraindo dados da tabela `sma_cst_ipi`
--

INSERT INTO `sma_cst_ipi` (`id`, `descricao`) VALUES
('0', '0 - Entrada com Recuperação de Crédito.'),
('1', '1 - Entrada Tributável com Alíquota Zero.'),
('2', '2 - Entrada Isenta.'),
('3', '3 - Entrada Não-Tributada.'),
('4', '4 - Entrada Imune.'),
('5', '5 - Entrada com Suspensão.'),
('49', '49 - Outras Entradas.'),
('50', '50 - Saída Tributada.'),
('51', '51 - Saída Tributável com Alíquota Zero.'),
('52', '52 - Saída Isenta.'),
('53', '53 - Saída Não-Tributada.'),
('54', '54 - Saída Imune.'),
('55', '55 - Saída com Suspensão.'),
('99', '99 - Outras Saídas.');
