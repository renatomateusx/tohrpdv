
--
-- Extraindo dados da tabela `sma_suspended_items`
--

INSERT INTO `sma_suspended_items` (`id`, `suspend_id`, `product_id`, `product_code`, `product_name`, `net_unit_price`, `unit_price`, `quantity`, `warehouse_id`, `item_tax`, `tax_rate_id`, `tax`, `discount`, `item_discount`, `subtotal`, `serial_no`, `option_id`, `product_type`, `real_unit_price`) VALUES
(2, 1, 1, '07327550', 'Produto Teste', '16.9500', '16.9500', '3.0000', 1, '0.0000', 1, '0.0000', '0', '0.0000', '50.8500', '', 0, 'standard', '16.9500'),
(3, 2, 1, '07327550', 'Produto Teste', '16.9500', '16.9500', '1.0000', 1, '0.0000', 1, '0.0000', '0', '0.0000', '16.9500', '', 0, 'standard', '16.9500');
