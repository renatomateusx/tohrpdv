
--
-- Extraindo dados da tabela `sma_cst_pis_cofins`
--

INSERT INTO `sma_cst_pis_cofins` (`id`, `descricao`) VALUES
('1', '1 - Operação Tributável com Alíquota Básica.'),
('2', '2 - Operação Tributável com Alíquota Diferenciada'),
('3', '3 - Operação Tributável com Alíquota por Unidade de Medida de Produto'),
('4', '4 - Operação Tributável Monofásica – Revenda a Alíquota Zero'),
('5', '5 - Operação Tributável por Substituição Tributária'),
('6', '6 - Operação Tributável a Alíquota Zero'),
('7', '7 - Operação Isenta da Contribuição'),
('8', '8 - Operação sem Incidência da Contribuição'),
('9', '9 - Operação com Suspensão da Contribuição'),
('49', '49 - Outras Operações de Saída'),
('50', '50 - Operação com Direito a Crédito – Vinculada Exclusivamente a Receita Tributada no Mercado Interno'),
('51', '51 - Operação com Direito a Crédito – Vinculada Exclusivamente a Receita Não Tributada no Mercado Interno'),
('52', '52 - Operação com Direito a Crédito – Vinculada Exclusivamente a Receita de Exportação'),
('53', '53 - Operação com Direito a Crédito – Vinculada a Receitas Tributadas e Não-Tributadas no Mercado Interno'),
('54', '54 - Operação com Direito a Crédito – Vinculada a Receitas Tributadas no Mercado Interno e de Exportação'),
('55', '55 - Operação com Direito a Crédito – Vinculada a Receitas Não-Tributadas no Mercado Interno e de Exportação'),
('56', '56 - Operação com Direito a Crédito – Vinculada a Receitas Tributadas e Não-Tributadas no Mercado Interno, e de Exportação'),
('60', '60 - Crédito Presumido – Operação de Aquisição Vinculada Exclusivamente a Receita Tributada no Mercado Interno'),
('61', '61 - Crédito Presumido – Operação de Aquisição Vinculada Exclusivamente a Receita Não-Tributada no Mercado Interno'),
('62', '62 - Crédito Presumido – Operação de Aquisição Vinculada Exclusivamente a Receita de Exportação'),
('63', '63 - Crédito Presumido – Operação de Aquisição Vinculada a Receitas Tributadas e Não-Tributadas no Mercado Interno'),
('64', '64 - Crédito Presumido – Operação de Aquisição Vinculada a Receitas Tributadas no Mercado Interno e de Exportação'),
('65', '65 - Crédito Presumido – Operação de Aquisição Vinculada a Receitas Não-Tributadas no Mercado Interno e de Exportação'),
('66', '66 - Crédito Presumido – Operação de Aquisição Vinculada a Receitas Tributadas e Não-Tributadas no Mercado Interno, e de Exportação'),
('67', '67 - Crédito Presumido – Outras Operações'),
('70', '70 - Operação de Aquisição sem Direito a Crédito'),
('71', '71 - Operação de Aquisição com Isenção'),
('72', '72 - Operação de Aquisição com Suspensão'),
('73', '73 - Operação de Aquisição a Alíquota Zero'),
('74', '74 - Operação de Aquisição sem Incidência da Contribuição'),
('75', '75 - Operação de Aquisição por Substituição Tributária'),
('98', '98 - Outras Operações de Entrada'),
('99', '99 - Outras Operações');
