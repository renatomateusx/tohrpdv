
--
-- Extraindo dados da tabela `sma_adjustments`
--

INSERT INTO `sma_adjustments` (`id`, `date`, `product_id`, `option_id`, `quantity`, `warehouse_id`, `note`, `created_by`, `updated_by`, `type`) VALUES
(1, '2019-02-12 20:05:00', 3, NULL, '100.0000', 1, '&lt;p&gt;asdfasdf&lt;&sol;p&gt;', 4, NULL, 'addition');
