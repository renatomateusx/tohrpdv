
--
-- Extraindo dados da tabela `sma_login_attempts`
--

INSERT INTO `sma_login_attempts` (`id`, `ip_address`, `login`, `time`) VALUES
(20, 0x3a3a31, 'Admin123456', 1550069446),
(21, 0x3a3a31, 'Admin123456', 1550073168),
(22, 0x3a3a31, 'Admin123456', 1550155160);
