
--
-- Extraindo dados da tabela `sma_companies`
--

INSERT INTO `sma_companies` (`id`, `group_id`, `group_name`, `customer_group_id`, `customer_group_name`, `name`, `company`, `vat_no`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `invoice_footer`, `payment_term`, `logo`, `award_points`, `deposit_amount`) VALUES
(1, 3, 'customer', 1, 'Geral', 'Cliente Teste', 'Cliente Teste', '092.738.336-59', 'Rua Jose Nenem', 'Ipiranga do Piaui', 'Piaui', '64540000', 'Brasil', '0123456789', 'cliente@hotmail.com', 'MG16252123', '120', 'Casa', 'F', 'Centro', '', NULL, 0, 'logo.png', 0, NULL),
(2, 4, 'supplier', NULL, NULL, 'GF', 'Fornecedor 1', '', 'Endereço', 'Cidade', 'MG', '37410-00', 'Brasil', '0123456789', 'fornecedor@gmail.com', '-', '-', '-', '-', '-', '-', NULL, 0, 'logo.png', 0, NULL),
(3, NULL, 'biller', NULL, NULL, 'Leonardo', 'Vendedor 2', '555.444.333-22', 'Endereço', 'Cidade', 'Bahia', '37410-00', 'Brasil', '012345678', 'vendendor@tohrpedv.com.br', '', '', '', '', '', '', '', 0, 'gopos.png', 0, NULL),
(4, NULL, 'biller', NULL, NULL, 'Vendedor 01', 'Vendedor 1', '', 'Rua Jose Nenem', 'Salvador', 'Bahia', '64540000', 'Brasil', '899999999', 'admin@admin.com', '', '', '', '', '', '', '', 0, 'gopos.png', 0, NULL),
(5, 3, 'customer', 1, 'Geral', 'testes teste', 'teste', '', 'teste', 'teste', '', '', '', '111113432411', 'teste@teste.com.br', '', '', '', '', '', '', NULL, 0, 'logo.png', 0, NULL),
(6, 3, 'customer', 1, 'Geral', 'ok', 'geral', '123456789', 'rua', 'sp', 'sp', '12345678', 'Brasil', '55501234', 'benderpcs@gmail.com', '', '', '', '', '', '', NULL, 0, 'logo.png', 0, NULL);
