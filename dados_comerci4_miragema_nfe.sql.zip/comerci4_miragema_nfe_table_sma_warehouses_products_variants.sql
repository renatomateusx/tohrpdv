
--
-- Extraindo dados da tabela `sma_warehouses_products_variants`
--

INSERT INTO `sma_warehouses_products_variants` (`id`, `option_id`, `product_id`, `warehouse_id`, `quantity`, `rack`) VALUES
(1, 1, 2, 1, '0.0000', NULL),
(2, 1, 2, 2, '0.0000', NULL),
(3, 2, 2, 1, '0.0000', NULL),
(4, 2, 2, 2, '0.0000', NULL);
