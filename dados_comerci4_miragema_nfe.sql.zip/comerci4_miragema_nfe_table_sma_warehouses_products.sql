
--
-- Extraindo dados da tabela `sma_warehouses_products`
--

INSERT INTO `sma_warehouses_products` (`id`, `product_id`, `warehouse_id`, `quantity`, `rack`, `avg_cost`) VALUES
(1, 1, 1, '299.0000', 'AB12', '11.5000'),
(2, 1, 2, '20.0000', 'BC10', '11.5000'),
(3, 2, 1, '0.0000', '1', '1.0000'),
(4, 3, 1, '1067.0000', NULL, '21.8182'),
(5, 3, 2, '0.0000', NULL, '0.0000');
