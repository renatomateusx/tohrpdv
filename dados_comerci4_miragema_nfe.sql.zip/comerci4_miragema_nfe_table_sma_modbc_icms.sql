
--
-- Extraindo dados da tabela `sma_modbc_icms`
--

INSERT INTO `sma_modbc_icms` (`id`, `descricao`) VALUES
(0, '0 - Margem Valor Agregado (%)'),
(1, '1 - Pauta (Valor) '),
(2, '2 - Preço Tabelado Máx. (valor)'),
(3, '3 - valor da operação');
