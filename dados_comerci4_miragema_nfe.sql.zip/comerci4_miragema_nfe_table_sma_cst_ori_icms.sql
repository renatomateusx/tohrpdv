
--
-- Extraindo dados da tabela `sma_cst_ori_icms`
--

INSERT INTO `sma_cst_ori_icms` (`id`, `descricao`) VALUES
('0', '0 - Nacional.'),
('1', '1 - Estrangeira Importação direta.'),
('2', '2 - Estrangeira Adquirida no mercado interno.');
