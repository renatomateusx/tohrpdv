
--
-- Extraindo dados da tabela `sma_cst_dest_icms`
--

INSERT INTO `sma_cst_dest_icms` (`id`, `descricao`) VALUES
('00', '00 - Tributada integralmente.'),
('10', '10 -Tributada e com cobrança do ICMS por substituição tributária.'),
('20', '20 - Com redução de base de cálculo.'),
('30', '30 - Isenta ou não tributada e com cobrança do ICMS por substituição tributária.'),
('40', '40 - Isenta.'),
('41', '41 - Não tributada'),
('50', '50 - Suspensão.'),
('51', '51 - Deferimento.'),
('60', '60 - ICMS cobrado anteriormente por substituição tributária.'),
('70', '70 - Com redução de base de cálculo e cobrança do ICMS por substituição tributária.'),
('90', '90 - Outras.');
