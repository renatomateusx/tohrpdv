
--
-- Extraindo dados da tabela `sma_categories`
--

INSERT INTO `sma_categories` (`id`, `code`, `name`, `image`) VALUES
(1, 'C1', 'Cimentos', NULL),
(2, '01', 'CIMENTOS', NULL);
