
--
-- Extraindo dados da tabela `sma_payments`
--

INSERT INTO `sma_payments` (`id`, `date`, `sale_id`, `return_id`, `purchase_id`, `reference_no`, `transaction_id`, `paid_by`, `cheque_no`, `cc_no`, `cc_holder`, `cc_month`, `cc_year`, `cc_type`, `amount`, `currency`, `created_by`, `attachment`, `type`, `note`, `pos_paid`, `pos_balance`, `approval_code`) VALUES
(1, '2016-05-18 18:36:00', NULL, NULL, 1, '458', NULL, 'cash', '', '', '', '', '', 'Visa', '115.0000', NULL, 1, NULL, 'sent', '', '0.0000', '0.0000', NULL),
(4, '2016-05-20 16:41:18', 4, NULL, NULL, 'IPAY/2016/05/0003', NULL, 'CC', '', '4145123600014698', 'Jean Luiz', '04', '2016', 'MasterCard', '33.9000', NULL, 1, NULL, 'received', '', '33.9000', '0.0000', NULL),
(5, '2016-05-25 10:56:24', 5, NULL, NULL, 'IPAY/2016/05/0004', NULL, 'cash', '', '', '', '', '', '', '33.9000', NULL, 1, NULL, 'received', '', '100.0000', '66.1000', NULL),
(6, '2016-07-28 15:17:35', 7, NULL, NULL, 'IPAY/2016/07/0005', NULL, 'cash', '', '', '', '', '', '', '50.8500', NULL, 2, NULL, 'received', '', '100.0000', '49.1500', NULL),
(7, '2017-05-08 13:31:12', 8, NULL, NULL, 'IPAY/2017/05/0001', NULL, 'cash', '', '', '', '', '', '', '16.9500', NULL, 2, NULL, 'received', '', '16.9500', '0.0000', NULL),
(8, '2017-05-23 00:00:26', 9, NULL, NULL, 'IPAY/2017/05/0002', NULL, 'cash', '', '', '', '', '', '', '16.9500', NULL, 2, NULL, 'received', '', '100.0000', '83.0500', NULL),
(9, '2017-05-30 00:45:17', 10, NULL, NULL, 'IPAY/2017/05/0003', NULL, 'cash', '', '', '', '', '', '', '16.9500', NULL, 2, NULL, 'received', '', '20.0000', '3.0500', NULL),
(10, '2017-05-30 10:36:10', 11, NULL, NULL, 'IPAY/2017/05/0001', NULL, 'cash', '', '', '', '', '', '', '16.9500', NULL, 2, NULL, 'received', '', '20.0000', '3.0500', NULL),
(11, '2017-06-01 13:01:53', 12, NULL, NULL, 'IPAY/2017/06/0002', NULL, 'cash', '', '', '', '', '', '', '16.9500', NULL, 2, NULL, 'received', '', '16.9500', '0.0000', NULL),
(12, '2017-06-01 13:06:49', 13, NULL, NULL, 'IPAY/2017/06/0003', NULL, 'cash', '', '', '', '', '', '', '16.9500', NULL, 2, NULL, 'received', '', '20.0000', '3.0500', NULL),
(13, '2017-06-05 18:46:40', 14, NULL, NULL, 'IPAY/2017/06/0001', NULL, 'cash', '', '', '', '', '', '', '16.9500', NULL, 2, NULL, 'received', '', '20.0000', '3.0500', NULL),
(14, '2017-06-06 14:58:36', 15, NULL, NULL, 'IPAY/2017/06/0002', NULL, 'cash', '', '', '', '', '', '', '16.9500', NULL, 2, NULL, 'received', '', '100.0000', '83.0500', NULL),
(15, '2017-06-09 22:59:53', 16, NULL, NULL, 'IPAY/2017/06/0003', NULL, 'cash', '', '', '', '', '', '', '33.9000', NULL, 3, NULL, 'received', '', '100.0000', '66.1000', NULL),
(16, '2017-06-11 04:44:17', 17, NULL, NULL, 'IPAY/2017/06/0004', NULL, 'cash', '', '', '', '', '', '', '20.0000', NULL, 2, NULL, 'received', '', '20.0000', '0.0000', NULL),
(17, '2017-06-11 13:10:44', 18, NULL, NULL, 'IPAY/2017/06/0005', NULL, 'cash', '', '', '', '', '', '', '10.6100', NULL, 2, NULL, 'received', '', '10.6100', '0.0000', NULL),
(18, '2017-06-11 15:17:33', 19, NULL, NULL, 'IPAY/2017/06/0006', NULL, 'cash', '', '', '', '', '', '', '2.1200', NULL, 2, NULL, 'received', '', '100.0000', '97.8800', NULL),
(19, '2017-06-11 15:17:49', 20, NULL, NULL, 'IPAY/2017/06/0007', NULL, 'cash', '', '', '', '', '', '', '2.0000', NULL, 2, NULL, 'received', '', '1222.0000', '1220.0000', NULL),
(20, '2017-06-11 16:51:56', 21, NULL, NULL, 'IPAY/2017/06/0008', NULL, 'cash', '', '', '', '', '', '', '4.0000', NULL, 2, NULL, 'received', '', '122222.0000', '122218.0000', NULL),
(21, '2017-06-12 10:58:50', 22, NULL, NULL, 'IPAY/2017/06/0009', NULL, 'cash', '', '', '', '', '', '', '2.0000', NULL, 2, NULL, 'received', '', '10.0000', '8.0000', NULL),
(22, '2019-01-28 15:57:00', 23, NULL, NULL, '123456', NULL, 'cash', '', '', '', '', '', 'Visa', '1800.0000', NULL, 4, NULL, 'received', '<p>Pago com cartão de crédito</p>', '0.0000', '0.0000', NULL),
(23, '2019-02-13 12:56:53', 25, NULL, NULL, 'IPAY/2019/02/0011', NULL, 'cash', '', '', '', '', '', '', '275.0000', NULL, 4, NULL, 'received', 'd', '275.0000', '0.0000', NULL),
(24, '2019-02-13 12:59:51', 26, NULL, NULL, 'IPAY/2019/02/0012', NULL, 'cash', '', '', '', '', '', '', '23.5000', NULL, 4, NULL, 'received', '', '25.0000', '1.5000', NULL),
(25, '2019-02-14 14:41:00', 24, NULL, NULL, '454', NULL, 'cash', '', '', '', '', '', 'Visa', '275.0000', NULL, 4, NULL, 'received', '', '0.0000', '0.0000', NULL),
(26, '2019-02-18 14:43:48', 27, NULL, NULL, 'IPAY/2019/02/0013', NULL, 'cash', '', '', '', '', '', '', '27.5000', NULL, 4, NULL, 'received', 'a', '28.0000', '0.5000', NULL),
(27, '2019-02-18 14:52:39', 28, NULL, NULL, 'IPAY/2019/02/0014', NULL, 'cash', '', '', '', '', '', '', '275.0000', NULL, 4, NULL, 'received', 'asdf', '275.0000', '0.0000', NULL),
(28, '2019-02-19 14:39:32', 29, NULL, NULL, 'IPAY/2019/02/0015', NULL, 'cash', '', '', '', '', '', '', '27.5000', NULL, 4, NULL, 'received', 'a', '27.5000', '0.0000', NULL),
(29, '2019-02-19 17:21:09', 30, NULL, NULL, 'IPAY/2019/02/0016', NULL, 'cash', '', '', '', '', '', '', '27.5000', NULL, 4, NULL, 'received', 'D', '28.0000', '0.5000', NULL);
