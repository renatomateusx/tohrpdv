
--
-- Extraindo dados da tabela `sma_users`
--

INSERT INTO `sma_users` (`id`, `last_ip_address`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`, `avatar`, `gender`, `group_id`, `warehouse_id`, `biller_id`, `company_id`, `show_cost`, `show_price`, `award_points`, `view_right`, `edit_right`, `allow_discount`) VALUES
(2, 0x3a3a31, 0x3a3a31, 'Administrador', 'e39bf8629927badccc8d90e515920acf2527dba1', NULL, 'admin@admcp.com', NULL, NULL, NULL, NULL, 0, 1548339077, 1, 'Admin', 'admin', 'Empresa administradora', '0011245552', NULL, 'male', 1, NULL, NULL, NULL, 0, 0, 100, 1, 0, 0),
(3, 0x3138392e312e3133302e3133, 0x3137372e34312e3134352e313732, 'admin', '5a77de053793514cb4963a9a6a7cc47a7a58bcdf', NULL, 'admin@comercioparalelo.com', NULL, NULL, NULL, 'c9ba91d8fe0d7d00c7bce30587f1d14a9d81ede4', 1497046636, 1497123836, 1, 'Admin2', 'Admin33', 'Admin', '1215422121212', NULL, 'male', 2, NULL, NULL, NULL, 0, 0, 0, 1, 0, 0),
(4, 0x3a3a31, 0x3a3a31, 'renatomateusx', '5b21be6959e98f854af5a20e524ff03045e5dab7', NULL, 'renatomateusx@gmail.com', NULL, NULL, NULL, NULL, 1548445517, 1550155171, 1, 'Renato', 'Moura', 'Comércio Paralelo', '71 99130-6561', NULL, 'male', 1, 0, 0, NULL, 0, 0, 0, 1, 0, 0);
