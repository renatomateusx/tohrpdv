
--
-- Extraindo dados da tabela `sma_modbc_icmsst`
--

INSERT INTO `sma_modbc_icmsst` (`id`, `descricao`) VALUES
(0, '0 - Preço tabelado ou máximo sugerido'),
(1, '1 - Lista Negativa (valor)'),
(2, '2 - Lista Positiva (valor)'),
(3, '3 - Lista Neutra (valor)'),
(4, '4 - Margem Valor Agregado (%)'),
(5, '5 - Pauta (valor)');
