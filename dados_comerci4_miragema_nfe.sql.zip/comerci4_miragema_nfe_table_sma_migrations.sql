
--
-- Extraindo dados da tabela `sma_migrations`
--

INSERT INTO `sma_migrations` (`version`) VALUES
(315);
