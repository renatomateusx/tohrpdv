
--
-- Extraindo dados da tabela `sma_suspended_bills`
--

INSERT INTO `sma_suspended_bills` (`id`, `date`, `customer_id`, `customer`, `count`, `order_discount_id`, `order_tax_id`, `total`, `biller_id`, `warehouse_id`, `created_by`, `suspend_note`) VALUES
(1, '2016-05-20 18:37:27', 1, 'MEGA SISTEMAS', 3, NULL, 1, '50.8500', 3, 1, 1, '01'),
(2, '2016-05-20 18:37:35', 1, 'MEGA SISTEMAS', 1, NULL, 1, '16.9500', 3, 1, 1, '02');
