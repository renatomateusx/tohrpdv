
--
-- Extraindo dados da tabela `sma_groups`
--

INSERT INTO `sma_groups` (`id`, `name`, `description`) VALUES
(1, 'owner', 'Proprietário'),
(2, 'admin', 'Administração'),
(3, 'customer', 'Clientes'),
(4, 'supplier', 'Fornecedores'),
(5, 'vendas', 'Equipe de Vendas');
