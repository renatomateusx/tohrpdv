
--
-- Extraindo dados da tabela `sma_customer_groups`
--

INSERT INTO `sma_customer_groups` (`id`, `name`, `percent`) VALUES
(1, 'Geral', 0),
(2, 'Revenda', -5),
(3, 'Distribuidor', -15),
(4, 'Cliente (+10)', 10);
