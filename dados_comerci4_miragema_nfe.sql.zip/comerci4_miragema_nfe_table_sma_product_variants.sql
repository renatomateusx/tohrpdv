
--
-- Extraindo dados da tabela `sma_product_variants`
--

INSERT INTO `sma_product_variants` (`id`, `product_id`, `name`, `cost`, `price`, `quantity`) VALUES
(1, 2, 'milho', '1.0000', '2.0000', NULL),
(2, 2, 'abacaxi', '0.0000', '0.0000', NULL);
