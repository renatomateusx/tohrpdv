
--
-- Extraindo dados da tabela `sma_warehouses`
--

INSERT INTO `sma_warehouses` (`id`, `code`, `name`, `address`, `map`, `phone`, `email`) VALUES
(1, '01', 'Estoque Empresa 1', '<p>Endereço, Cidade</p>', NULL, '012345678', 'empresa1@jr.com'),
(2, '02', 'Estoque Empresa 2', '<p>Endereço, Cidade</p>', NULL, '0105292122', 'empresa2@jr.com');
