
--
-- Extraindo dados da tabela `sma_crt`
--

INSERT INTO `sma_crt` (`id`, `descricao`) VALUES
(1, 'Simples Nacional.'),
(2, 'Simples Nacional - Excesso de Sublimite de Receita Bruta.'),
(3, 'Regime Normal.');
