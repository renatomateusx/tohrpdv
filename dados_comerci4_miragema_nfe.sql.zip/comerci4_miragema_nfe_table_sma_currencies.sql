
--
-- Extraindo dados da tabela `sma_currencies`
--

INSERT INTO `sma_currencies` (`id`, `code`, `name`, `rate`, `auto_update`) VALUES
(1, 'BRL', 'Real', '1.0000', 0);
