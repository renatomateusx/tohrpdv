
--
-- Extraindo dados da tabela `sma_order_ref`
--

INSERT INTO `sma_order_ref` (`ref_id`, `date`, `so`, `qu`, `po`, `to`, `pos`, `do`, `pay`, `re`, `rep`, `ex`) VALUES
(1, '2017-06-01', 2, 1, 1, 1, 16, 1, 17, 1, 1, 1);
