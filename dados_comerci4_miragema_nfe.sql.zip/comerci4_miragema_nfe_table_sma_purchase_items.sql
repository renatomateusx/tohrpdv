
--
-- Extraindo dados da tabela `sma_purchase_items`
--

INSERT INTO `sma_purchase_items` (`id`, `purchase_id`, `transfer_id`, `product_id`, `product_code`, `product_name`, `option_id`, `net_unit_cost`, `quantity`, `warehouse_id`, `item_tax`, `tax_rate_id`, `tax`, `discount`, `item_discount`, `expiry`, `subtotal`, `quantity_balance`, `date`, `status`, `unit_cost`, `real_unit_cost`, `quantity_received`, `supplier_part_no`, `purchase_item_id`) VALUES
(1, NULL, NULL, 1, '07327550', 'Produto Teste', NULL, '11.5000', '10.0000', 1, '0.0000', 1, '0.0000', NULL, NULL, NULL, '115.0000', '0.0000', '2016-05-18', 'received', '11.5000', '11.5000', NULL, NULL, NULL),
(2, NULL, NULL, 1, '07327550', 'Produto Teste', NULL, '11.5000', '20.0000', 2, '0.0000', 1, '0.0000', NULL, NULL, NULL, '230.0000', '20.0000', '2016-05-18', 'received', '11.5000', '11.5000', NULL, NULL, NULL),
(3, 1, NULL, 1, '07327550', 'Produto Teste', NULL, '11.5000', '10.0000', 1, '0.0000', 1, '0.0000', '0', '0.0000', NULL, '115.0000', '299.0000', '2016-05-18', 'received', '11.5000', '11.5000', '10.0000', NULL, NULL),
(4, NULL, NULL, 2, '1234', 'teste', 1, '0.9091', '10.0000', 1, '0.9091', 2, '10.0000%', NULL, NULL, NULL, '10.0000', '0.0000', '2017-06-11', 'received', '1.0000', NULL, NULL, NULL, NULL),
(5, NULL, NULL, 3, '4885453756465468465465465', 'CIMENTO MONTES CLAROS', NULL, '0.0000', '0.0000', 1, '0.0000', 0, '', NULL, NULL, NULL, '0.0000', '100.0000', '2019-02-12', 'received', '0.0000', NULL, NULL, NULL, NULL),
(6, 2, NULL, 3, '4885453756465468465465465', 'CIMENTO MONTES CLAROS', NULL, '24.0000', '1000.0000', 1, '0.0000', 1, '0.0000', '0', '0.0000', NULL, '24000.0000', '967.0000', '2019-02-12', 'received', '24.0000', '24.0000', '1000.0000', NULL, NULL);
