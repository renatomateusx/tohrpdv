
--
-- Extraindo dados da tabela `sma_purchases`
--

INSERT INTO `sma_purchases` (`id`, `reference_no`, `date`, `supplier_id`, `supplier`, `warehouse_id`, `note`, `total`, `product_discount`, `order_discount_id`, `order_discount`, `total_discount`, `product_tax`, `order_tax_id`, `order_tax`, `total_tax`, `shipping`, `grand_total`, `paid`, `status`, `payment_status`, `created_by`, `updated_by`, `updated_at`, `attachment`, `payment_term`, `due_date`, `return_id`, `surcharge`, `return_purchase_ref`, `purchase_id`, `return_purchase_total`) VALUES
(1, 'PO/2016/05/0001', '2016-05-18 18:31:00', 2, 'MEGA SISTEMAS', 1, '', '115.0000', '0.0000', NULL, '0.0000', '0.0000', '0.0000', 1, '0.0000', '0.0000', '0.0000', '115.0000', '115.0000', 'received', 'paid', 1, NULL, NULL, NULL, 0, NULL, NULL, '0.0000', NULL, NULL, '0.0000'),
(2, '123', '2019-02-12 22:59:00', 2, 'Fornecedor 1', 1, '&lt;p&gt;SDF&lt;&sol;p&gt;', '24000.0000', '0.0000', NULL, '0.0000', '0.0000', '0.0000', 1, '0.0000', '0.0000', '0.0000', '24000.0000', '0.0000', 'received', 'pending', 4, NULL, NULL, NULL, 0, NULL, NULL, '0.0000', NULL, NULL, '0.0000');
