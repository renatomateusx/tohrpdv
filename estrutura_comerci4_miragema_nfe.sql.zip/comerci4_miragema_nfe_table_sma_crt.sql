
-- --------------------------------------------------------

--
-- Estrutura da tabela `sma_crt`
--

CREATE TABLE IF NOT EXISTS `sma_crt` (
  `id` bigint(100) NOT NULL,
  `descricao` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
