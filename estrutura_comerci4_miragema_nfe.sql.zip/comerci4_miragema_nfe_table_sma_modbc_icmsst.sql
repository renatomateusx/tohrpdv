
-- --------------------------------------------------------

--
-- Estrutura da tabela `sma_modbc_icmsst`
--

CREATE TABLE IF NOT EXISTS `sma_modbc_icmsst` (
  `id` int(10) NOT NULL,
  `descricao` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
