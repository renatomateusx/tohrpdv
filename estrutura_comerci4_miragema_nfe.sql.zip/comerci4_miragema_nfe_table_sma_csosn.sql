
-- --------------------------------------------------------

--
-- Estrutura da tabela `sma_csosn`
--

CREATE TABLE IF NOT EXISTS `sma_csosn` (
  `id` bigint(100) NOT NULL,
  `descricao` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
