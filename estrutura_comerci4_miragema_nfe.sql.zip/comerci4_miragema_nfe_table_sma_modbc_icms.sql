
-- --------------------------------------------------------

--
-- Estrutura da tabela `sma_modbc_icms`
--

CREATE TABLE IF NOT EXISTS `sma_modbc_icms` (
  `id` int(10) NOT NULL,
  `descricao` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
