
-- --------------------------------------------------------

--
-- Estrutura da tabela `sma_cfop`
--

CREATE TABLE IF NOT EXISTS `sma_cfop` (
  `id` char(4) COLLATE utf8_unicode_ci NOT NULL,
  `descricao` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `aplicacao` varchar(530) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
