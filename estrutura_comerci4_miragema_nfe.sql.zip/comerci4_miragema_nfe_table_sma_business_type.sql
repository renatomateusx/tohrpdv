
-- --------------------------------------------------------

--
-- Estrutura da tabela `sma_business_type`
--

CREATE TABLE IF NOT EXISTS `sma_business_type` (
  `id` int(2) NOT NULL,
  `descricao` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
