
-- --------------------------------------------------------

--
-- Estrutura da tabela `sma_nfe_register`
--

CREATE TABLE IF NOT EXISTS `sma_nfe_register` (
  `id` bigint(100) NOT NULL AUTO_INCREMENT,
  `cod_nfe` bigint(100) NOT NULL,
  `id_lote` bigint(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
