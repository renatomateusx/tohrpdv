
-- --------------------------------------------------------

--
-- Estrutura da tabela `sma_cst_ipi`
--

CREATE TABLE IF NOT EXISTS `sma_cst_ipi` (
  `id` char(2) NOT NULL,
  `descricao` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
