
-- --------------------------------------------------------

--
-- Estrutura da tabela `sma_cst_pis_cofins`
--

CREATE TABLE IF NOT EXISTS `sma_cst_pis_cofins` (
  `id` char(3) NOT NULL,
  `descricao` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
