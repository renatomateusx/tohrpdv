
-- --------------------------------------------------------

--
-- Estrutura da tabela `sma_ncm`
--

CREATE TABLE IF NOT EXISTS `sma_ncm` (
  `cod_ncm` int(11) NOT NULL AUTO_INCREMENT,
  `ncm` varchar(8) DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cod_ncm`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
