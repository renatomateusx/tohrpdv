
-- --------------------------------------------------------

--
-- Estrutura da tabela `sma_cst_dest_icms`
--

CREATE TABLE IF NOT EXISTS `sma_cst_dest_icms` (
  `id` char(3) NOT NULL,
  `descricao` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
