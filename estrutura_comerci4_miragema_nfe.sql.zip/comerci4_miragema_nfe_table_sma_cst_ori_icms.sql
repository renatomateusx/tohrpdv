
-- --------------------------------------------------------

--
-- Estrutura da tabela `sma_cst_ori_icms`
--

CREATE TABLE IF NOT EXISTS `sma_cst_ori_icms` (
  `id` char(1) NOT NULL,
  `descricao` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
